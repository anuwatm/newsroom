<?php
/**
 * api.php
 * Handles JSON requests to save and load stories from SQLite
 */

require_once 'db.php';
header('Content-Type: application/json');

// Ensure data directory exists
$dataDir = __DIR__ . '/data/stories';
if (!is_dir($dataDir)) {
    mkdir($dataDir, 0755, true);
}

// Ensure migrations for new columns
try {
    $db->exec("CREATE TABLE IF NOT EXISTS rundowns (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        broadcast_time DATETIME NOT NULL,
        target_trt INTEGER NOT NULL DEFAULT 0,
        is_locked INTEGER DEFAULT 0,
        created_by TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
} catch (Exception $e) {}

try {
    $db->exec("CREATE TABLE IF NOT EXISTS rundown_stories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        rundown_id INTEGER NOT NULL,
        story_id INTEGER NOT NULL,
        order_index INTEGER NOT NULL DEFAULT 0,
        is_dropped INTEGER DEFAULT 0,
        FOREIGN KEY(rundown_id) REFERENCES rundowns(id) ON DELETE CASCADE,
        FOREIGN KEY(story_id) REFERENCES stories(id) ON DELETE CASCADE
    )");
} catch (Exception $e) {}

try {
    $db->exec("ALTER TABLE rundown_stories ADD COLUMN is_break INTEGER DEFAULT 0");
} catch (Exception $e) {}
try {
    $db->exec("ALTER TABLE rundown_stories ADD COLUMN break_duration INTEGER DEFAULT 0");
} catch (Exception $e) {}

try {
    $db->exec("CREATE TABLE IF NOT EXISTS programs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        duration INTEGER NOT NULL DEFAULT 0,
        break_count INTEGER NOT NULL DEFAULT 0
    )");
} catch (Exception $e) {}

try {
    $db->exec("ALTER TABLE rundowns ADD COLUMN program_id INTEGER");
} catch (Exception $e) {}

try {
    $db->exec("ALTER TABLE stories ADD COLUMN current_version INTEGER DEFAULT 0");
} catch (Exception $e) { /* Column already exists */ }
try {
    $db->exec("ALTER TABLE stories ADD COLUMN keywords TEXT");
} catch (Exception $e) { /* Column already exists */ }
try {
    $db->exec("ALTER TABLE stories ADD COLUMN keyword_soundex TEXT");
} catch (Exception $e) { /* Column already exists */ }
try {
    $db->exec("ALTER TABLE stories ADD COLUMN is_deleted INTEGER DEFAULT 0");
} catch (Exception $e) { /* Column already exists */ }
try {
    $db->exec("ALTER TABLE stories ADD COLUMN locked_by TEXT");
} catch (Exception $e) { /* Column already exists */ }
try {
    $db->exec("ALTER TABLE stories ADD COLUMN locked_at DATETIME");
} catch (Exception $e) { /* Column already exists */ }

session_start();
if (!isset($_SESSION['user'])) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized. Please log in.']);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

if ($method === 'POST' && $action === 'save_story') {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!$data) {
        echo json_encode(['success' => false, 'error' => 'Invalid JSON Payload']);
        exit;
    }

    try {
        // Validate CSRF token
        if (!isset($data['csrf_token']) || $data['csrf_token'] !== $_SESSION['csrf_token']) {
            echo json_encode(['success' => false, 'error' => 'Invalid CSRF token. Security block.']);
            exit;
        }

        $db->beginTransaction();

        $storyId = $data['id'] ?? null;
        if ($storyId) $storyId = intval($storyId);
        $meta = $data['metadata'];

        $user = $_SESSION['user'];
        $role_id = $user['role_id'];
        $user_dept = $user['department_id'];
        $target_dept = $meta['department'];

        // 1. Permission Check: Can edit this department?
        if ($role_id == 1 || $role_id == 2) { // 1: Reporter, 2: Editor
            if ($target_dept != $user_dept) {
                $db->rollBack();
                echo json_encode(['success' => false, 'error' => 'Permission Denied: You can only create/edit stories in your own department.']);
                exit;
            }
        }

        // 2. Permission Check: Can approve?
        if ($meta['status'] === 'APPROVED') {
            if ($role_id == 1 || $role_id == 4) { // 1: Reporter, 4: Rewriter
                $db->rollBack();
                echo json_encode(['success' => false, 'error' => 'Permission Denied: You do not have permission to approve stories.']);
                exit;
            }
        }

        $is_autosave = isset($data['is_autosave']) ? $data['is_autosave'] : false;
        $newVersion = 1;
        
        $keywords = $meta['keywords'] ?? '';
        $soundexStr = '';
        if (!empty($keywords)) {
            $words = array_map('trim', explode(',', $keywords));
            $s_keys = [];
            foreach ($words as $w) {
                if(empty($w)) continue;
                $s1 = soundex($w);
                $s2 = thai_soundex($w);
                if ($s1) $s_keys[] = $s1;
                if ($s2) $s_keys[] = $s2;
            }
            $soundexStr = implode(' ', array_unique($s_keys));
        }

        if ($storyId) {
            // Verify Lock
            $stmtLock = $db->prepare("SELECT locked_by, locked_at FROM stories WHERE id=?");
            $stmtLock->execute([$storyId]);
            $lockStatus = $stmtLock->fetch(PDO::FETCH_ASSOC);
            if ($lockStatus) {
                $locked_by = $lockStatus['locked_by'];
                $locked_at = $lockStatus['locked_at'];
                $fallbackId = $user['employee_id'] ?? $user['id'] ?? $user['full_name'];
                if (!empty($locked_by) && $locked_by !== $fallbackId) {
                    if (!empty($locked_at) && (time() - strtotime($locked_at)) < 300) {
                        $db->rollBack();
                        echo json_encode(['success' => false, 'error' => "Story is currently locked by {$locked_by}. Please wait or try again later."]);
                        exit;
                    }
                }
            }

            // Update existing story
            $stmt = $db->prepare("SELECT current_version FROM stories WHERE id=?");
            $stmt->execute([$storyId]);
            $currentStory = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $currentVersion = $currentStory['current_version'] ?? 0;
            // หากเป็น Auto-save ให้ใช้เวอร์ชันเก่าเซฟทับ หากผู้ใช้กด Save ให้ขึ้นเวอร์ชันใหม่
            $newVersion = ($is_autosave && $currentVersion > 0) ? $currentVersion : $currentVersion + 1;

            $stmt = $db->prepare("UPDATE stories SET slug=?, format=?, reporter=?, anchor=?, department_id=?, status=?, estimated_time=?, current_version=?, keywords=?, keyword_soundex=?, locked_by=?, locked_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP WHERE id=?");
            $stmt->execute([$meta['slug'], $meta['format'], $meta['reporter'], $meta['anchor'], $meta['department'], $meta['status'], $meta['estimated_time'], $newVersion, $keywords, $soundexStr, ($user['employee_id'] ?? $user['id'] ?? $user['full_name']), $storyId]);
        } else {
            // Insert new story
            $stmt = $db->prepare("INSERT INTO stories (slug, format, reporter, anchor, department_id, status, estimated_time, current_version, keywords, keyword_soundex) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?)");
            $stmt->execute([$meta['slug'], $meta['format'], $meta['reporter'], $meta['anchor'], $meta['department'], $meta['status'], $meta['estimated_time'], $keywords, $soundexStr]);
            $storyId = $db->lastInsertId();
        }

        // Save content to a versioned text file
        if (isset($data['content']) && is_array($data['content'])) {
            $filePath = $dataDir . '/story_' . $storyId . '_v' . $newVersion . '.json';
            file_put_contents($filePath, json_encode($data['content'], JSON_UNESCAPED_UNICODE));
        }

        $db->commit();
        echo json_encode(['success' => true, 'story_id' => $storyId]);
    } catch (Exception $e) {
        $db->rollBack();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }

} elseif ($method === 'POST' && $action === 'lock_story') {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!isset($data['csrf_token']) || $data['csrf_token'] !== $_SESSION['csrf_token']) {
        echo json_encode(['success' => false, 'error' => 'Invalid CSRF token.']);
        exit;
    }
    
    $storyId = $data['id'] ?? null;
    $user = $_SESSION['user'];
    $empId = $user['employee_id'] ?? $user['id'] ?? $user['full_name'];
    
    if (!$storyId) {
        echo json_encode(['success' => false, 'error' => 'Missing story ID']);
        exit;
    }

    // Check current lock status
    $stmt = $db->prepare("SELECT department_id, locked_by, locked_at FROM stories WHERE id=?");
    $stmt->execute([$storyId]);
    $story = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($story) {
        // Permissions validation
        $target_dept = $story['department_id'];
        $role_id = $user['role_id'];
        $user_dept = $user['department_id'];
        if (($role_id == 1 || $role_id == 2) && $target_dept != $user_dept) {
            echo json_encode(['success' => false, 'locked' => true, 'locked_by' => 'Permission Denied']);
            exit;
        }

        $locked_by = $story['locked_by'];
        $locked_at = $story['locked_at'];
        
        $is_locked_by_other = false;
        if (!empty($locked_by) && $locked_by !== $empId) {
            if (!empty($locked_at) && (time() - strtotime($locked_at)) < 300) { // 5 minutes lock duration
                $is_locked_by_other = true;
            }
        }

        if ($is_locked_by_other) {
            echo json_encode(['success' => false, 'locked' => true, 'locked_by' => $locked_by]);
            exit;
        }

        // Apply lock
        $stmt = $db->prepare("UPDATE stories SET locked_by=?, locked_at=CURRENT_TIMESTAMP WHERE id=?");
        $stmt->execute([$empId, $storyId]);
        echo json_encode(['success' => true, 'locked' => false]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Story not found']);
    }

} elseif ($method === 'POST' && $action === 'unlock_story') {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!isset($data['csrf_token']) || $data['csrf_token'] !== $_SESSION['csrf_token']) {
        echo json_encode(['success' => false, 'error' => 'Invalid CSRF token.']);
        exit;
    }
    
    $storyId = $data['id'] ?? null;
    $user = $_SESSION['user'];
    $empId = $user['employee_id'] ?? $user['id'] ?? $user['full_name'];
    
    if ($storyId) {
        // Unlock only if currently locked by this user
        $stmt = $db->prepare("UPDATE stories SET locked_by=NULL, locked_at=NULL WHERE id=? AND locked_by=?");
        $stmt->execute([$storyId, $empId]);
    }
    echo json_encode(['success' => true]);

} elseif ($method === 'GET' && $action === 'get_story') {
    $storyId = $_GET['id'] ?? null;
    if ($storyId) $storyId = intval($storyId);
    
    if (!$storyId) {
        echo json_encode(['success' => false, 'error' => 'No story ID provided']);
        exit;
    }

    $stmt = $db->prepare("SELECT * FROM stories WHERE id=?");
    $stmt->execute([$storyId]);
    $story = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$story) {
        echo json_encode(['success' => false, 'error' => 'Story not found']);
        exit;
    }

    $user = $_SESSION['user'];
    $role_id = $user['role_id'];
    $user_dept = $user['department_id'];

    if (($role_id == 1 || $role_id == 2) && $story['department_id'] != $user_dept) {
        echo json_encode(['success' => false, 'error' => 'Permission Denied: You cannot read stories from other departments.']);
        exit;
    }

    $content = [];
    $version = $story['current_version'] ?? 0;
    
    // Check for Hybrid File version first
    $filePath = __DIR__ . '/data/stories/story_' . $storyId . '_v' . $version . '.json';
    if ($version > 0 && file_exists($filePath)) {
        $content = json_decode(file_get_contents($filePath), true);
    } else {
        // Legacy Database Fallback Loader
        $stmtRows = $db->prepare("SELECT * FROM story_rows WHERE story_id=? ORDER BY row_order ASC");
        $stmtRows->execute([$storyId]);
        $rows = $stmtRows->fetchAll(PDO::FETCH_ASSOC);

        $content = array_map(function ($row) {
            return [
                'type' => $row['type'],
                'leftColumn' => json_decode($row['left_column_json'], true),
                'rightColumn' => [
                    'text' => $row['right_column_text'],
                    'wordCount' => $row['word_count'],
                    'readTimeSeconds' => $row['estimated_read_time']
                ]
            ];
        }, $rows);
    }

    $is_locked_by_other = false;
    $locked_by = $story['locked_by'];
    $locked_at = $story['locked_at'];
    $fallbackId = $user['employee_id'] ?? $user['id'] ?? $user['full_name'];

    if (!empty($locked_by) && $locked_by !== $fallbackId) {
        if (!empty($locked_at) && (time() - strtotime($locked_at)) < 300) {
            $is_locked_by_other = true;
        }
    }

    echo json_encode([
        'success' => true,
        'data' => [
            'id' => $story['id'],
            'is_locked' => $is_locked_by_other,
            'locked_by' => $is_locked_by_other ? $locked_by : null,
            'metadata' => [
                'slug' => $story['slug'],
                'format' => $story['format'],
                'reporter' => $story['reporter'],
                'anchor' => $story['anchor'],
                'department' => $story['department_id'],
                'status' => $story['status'],
                'estimated_time' => $story['estimated_time'],
                'keywords' => $story['keywords'] ?? ''
            ],
            'content' => $content
        ]
    ]);
} elseif ($method === 'GET' && $action === 'get_departments') {
    $stmt = $db->query("SELECT id, name FROM departments ORDER BY id ASC");
    echo json_encode(['success' => true, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
} elseif ($method === 'GET' && $action === 'get_users') {
    $stmt = $db->query("SELECT id, full_name as name FROM users ORDER BY full_name ASC");
    echo json_encode(['success' => true, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
} elseif ($method === 'GET' && $action === 'search_stories') {
    $dept_id = $_GET['department_id'] ?? '';
    $keyword = $_GET['keyword'] ?? '';
    $exclude_draft = isset($_GET['exclude_draft']) && $_GET['exclude_draft'] == '1';
    $kw = "%$keyword%";

    $query = "SELECT DISTINCT s.id, s.slug, s.updated_at, d.name as department_name, s.status 
              FROM stories s
              LEFT JOIN departments d ON s.department_id = d.id
              WHERE s.is_deleted = 0";
    $params = [];
    
    if ($exclude_draft) {
        $query .= " AND s.status != 'DRAFT'";
    }

    $user = $_SESSION['user'];
    $role_id = $user['role_id'];
    $user_dept = $user['department_id'];

    if ($role_id == 1 || $role_id == 2) {
        $dept_id = $user_dept; // Force scope to user's assigned department
    }

    if ($dept_id !== '') {
        $query .= " AND s.department_id = ?";
        $params[] = $dept_id;
    }

    if ($keyword !== '') {
        $query .= " AND (s.slug LIKE ? OR s.anchor LIKE ?";
        $params[] = $kw;
        $params[] = $kw;
        
        $t_sound = thai_soundex($keyword);
        if (!empty($t_sound)) {
            $query .= " OR s.keyword_soundex LIKE ?";
            $params[] = "%" . $t_sound . "%";
        }
        
        $e_sound = soundex($keyword);
        // PHP soundex() typically returns 4 chars (e.g. S000). A single letter fallback like "A000" might be too broad if keyword is just 'a', but standard soundex matches will work. We just avoid empty strings.
        if (!empty($e_sound) && strlen($keyword) > 1) {
            $query .= " OR s.keyword_soundex LIKE ?";
            $params[] = "%" . $e_sound . "%";
        }
        
        $query .= ")";
    }

    $query .= " ORDER BY s.updated_at DESC LIMIT 50";

    $stmt = $db->prepare($query);
    $stmt->execute($params);
    echo json_encode(['success' => true, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
} elseif ($method === 'GET' && $action === 'get_my_stories') {
    $is_bin = isset($_GET['is_bin']) && $_GET['is_bin'] == '1' ? 1 : 0;
    $user = $_SESSION['user'];
    
    $query = "SELECT s.id, s.slug, s.updated_at, d.name as department_name, s.status 
              FROM stories s
              LEFT JOIN departments d ON s.department_id = d.id
              WHERE s.reporter = ? AND s.is_deleted = ?
              ORDER BY s.updated_at DESC LIMIT 100";
    $stmt = $db->prepare($query);
    $stmt->execute([$user['full_name'], $is_bin]);
    
    echo json_encode(['success' => true, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
} elseif ($method === 'POST' && $action === 'move_to_bin') {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!isset($data['csrf_token']) || $data['csrf_token'] !== $_SESSION['csrf_token']) {
        echo json_encode(['success' => false, 'error' => 'Invalid CSRF token.']);
        exit;
    }
    
    $storyId = $data['id'] ?? null;
    $user = $_SESSION['user'];
    
    if (!$storyId) {
        echo json_encode(['success' => false, 'error' => 'Missing story ID']);
        exit;
    }
    
    $stmt = $db->prepare("UPDATE stories SET is_deleted = 1 WHERE id = ? AND reporter = ? AND status = 'DRAFT'");
    $stmt->execute([$storyId, $user['full_name']]);
    
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Could not delete story. It may not belong to you or is not a DRAFT.']);
    }

} elseif ($method === 'POST' && $action === 'create_rundown') {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!isset($data['csrf_token']) || $data['csrf_token'] !== $_SESSION['csrf_token']) {
        echo json_encode(['success' => false, 'error' => 'Invalid CSRF token.']);
        exit;
    }
    
    $user = $_SESSION['user'];
    if ($user['role_id'] != 3) {
        echo json_encode(['success' => false, 'error' => 'Permission Denied: Only Main Editor can create a Rundown.']);
        exit;
    }
    
    $program_id = $data['program_id'] ?? null;
    $name = $data['name'] ?? 'New Rundown';
    $broadcast_time = $data['broadcast_time'] ?? date('Y-m-d H:i:s');
    $target_trt = intval($data['target_trt'] ?? 0);
    $empId = $user['employee_id'] ?? $user['id'] ?? $user['full_name'];
    
    $stmt = $db->prepare("INSERT INTO rundowns (name, broadcast_time, target_trt, created_by, program_id) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$name, $broadcast_time, $target_trt, $empId, $program_id]);
    $rundownId = $db->lastInsertId();

    $breakCount = intval($data['break_count'] ?? 0);
    if ($breakCount > 0) {
        $stmtCheckBreak = $db->query("SELECT id FROM stories WHERE format='BREAK' AND slug='--- COMMERCIAL BREAK ---' LIMIT 1");
        $breakStoryId = $stmtCheckBreak->fetchColumn();
        if (!$breakStoryId) {
            $db->exec("INSERT INTO stories (slug, format, estimated_time, status, is_deleted) VALUES ('--- COMMERCIAL BREAK ---', 'BREAK', 180, 'APPROVED', 1)");
            $breakStoryId = $db->lastInsertId();
        }
        
        $stmtRunStore = $db->prepare("INSERT INTO rundown_stories (rundown_id, story_id, order_index, is_break, break_duration) VALUES (?, ?, ?, 1, 180)");
        
        for ($i = 0; $i < $breakCount; $i++) {
            $stmtRunStore->execute([$rundownId, $breakStoryId, $i + 1]);
        }
    }
    
    echo json_encode(['success' => true, 'id' => $rundownId]);

} elseif ($method === 'GET' && $action === 'get_rundowns') {
    $stmt = $db->query("SELECT * FROM rundowns ORDER BY broadcast_time DESC");
    echo json_encode(['success' => true, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);

} elseif ($method === 'GET' && $action === 'get_rundown_data') {
    $rundownId = $_GET['id'] ?? null;
    if (!$rundownId) {
        echo json_encode(['success' => false, 'error' => 'Missing rundown ID']);
        exit;
    }
    
    $stmt = $db->prepare("SELECT * FROM rundowns WHERE id=?");
    $stmt->execute([$rundownId]);
    $rundown = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$rundown) {
        echo json_encode(['success' => false, 'error' => 'Rundown not found']);
        exit;
    }
    
    $stmtStories = $db->prepare("
        SELECT rs.id as rundown_story_id, rs.order_index, rs.is_dropped, rs.is_break, rs.break_duration,
               s.id, s.slug, s.format, s.reporter, s.status, 
               CASE WHEN rs.is_break = 1 THEN rs.break_duration ELSE s.estimated_time END as estimated_time, 
               s.updated_at, d.name as department_name
        FROM rundown_stories rs
        JOIN stories s ON rs.story_id = s.id
        LEFT JOIN departments d ON s.department_id = d.id
        WHERE rs.rundown_id = ?
        ORDER BY rs.order_index ASC
    ");
    $stmtStories->execute([$rundownId]);
    $rundown['stories'] = $stmtStories->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode(['success' => true, 'data' => $rundown]);

} elseif ($method === 'POST' && $action === 'add_rundown_story') {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!isset($data['csrf_token']) || $data['csrf_token'] !== $_SESSION['csrf_token']) {
        echo json_encode(['success' => false, 'error' => 'Invalid CSRF token.']);
        exit;
    }
    
    $rundownId = $data['rundown_id'] ?? null;
    $storyId = $data['story_id'] ?? null;
    $user = $_SESSION['user'];
    
    if ($user['role_id'] != 3) {
        echo json_encode(['success' => false, 'error' => 'Permission Denied']);
        exit;
    }
    
    if (!$rundownId || !$storyId) {
        echo json_encode(['success' => false, 'error' => 'Missing IDs']);
        exit;
    }
    
    $stmtDup = $db->prepare("SELECT COUNT(*) FROM rundown_stories WHERE rundown_id=? AND story_id=?");
    $stmtDup->execute([$rundownId, $storyId]);
    if ($stmtDup->fetchColumn() > 0) {
        echo json_encode(['success' => false, 'error' => 'Story is already in this rundown.']);
        exit;
    }
    
    // Check if story is approved
    $stmtCheck = $db->prepare("SELECT status FROM stories WHERE id=?");
    $stmtCheck->execute([$storyId]);
    $story = $stmtCheck->fetch(PDO::FETCH_ASSOC);
    
    if (!$story || $story['status'] === 'DRAFT') {
        echo json_encode(['success' => false, 'error' => 'Draft stories cannot be added to rundown.']);
        exit;
    }

    $stmtMax = $db->prepare("SELECT MAX(order_index) FROM rundown_stories WHERE rundown_id=?");
    $stmtMax->execute([$rundownId]);
    $maxOrder = intval($stmtMax->fetchColumn()) + 1;
    
    $stmt = $db->prepare("INSERT INTO rundown_stories (rundown_id, story_id, order_index) VALUES (?, ?, ?)");
    $stmt->execute([$rundownId, $storyId, $maxOrder]);
    
    echo json_encode(['success' => true]);

} elseif ($method === 'POST' && $action === 'add_rundown_break') {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!isset($data['csrf_token']) || $data['csrf_token'] !== $_SESSION['csrf_token']) {
        echo json_encode(['success' => false, 'error' => 'Invalid CSRF token.']);
        exit;
    }
    
    $rundownId = $data['rundown_id'] ?? null;
    $duration = intval($data['duration'] ?? 180);
    $user = $_SESSION['user'];
    
    if ($user['role_id'] != 3) {
        echo json_encode(['success' => false, 'error' => 'Permission Denied']);
        exit;
    }
    
    if (!$rundownId) {
        echo json_encode(['success' => false, 'error' => 'Missing IDs']);
        exit;
    }

    // Insert dummy record in stories marked as deleted so it won't show in search
    $stmtCheckBreak = $db->query("SELECT id FROM stories WHERE format='BREAK' AND slug='--- COMMERCIAL BREAK ---' LIMIT 1");
    $breakStoryId = $stmtCheckBreak->fetchColumn();
    if (!$breakStoryId) {
        $db->exec("INSERT INTO stories (slug, format, estimated_time, status, is_deleted) VALUES ('--- COMMERCIAL BREAK ---', 'BREAK', 180, 'APPROVED', 1)");
        $breakStoryId = $db->lastInsertId();
    }

    $stmtMax = $db->prepare("SELECT MAX(order_index) FROM rundown_stories WHERE rundown_id=?");
    $stmtMax->execute([$rundownId]);
    $maxOrder = intval($stmtMax->fetchColumn()) + 1;
    
    $stmt = $db->prepare("INSERT INTO rundown_stories (rundown_id, story_id, order_index, is_break, break_duration) VALUES (?, ?, ?, 1, ?)");
    $stmt->execute([$rundownId, $breakStoryId, $maxOrder, $duration]);
    
    echo json_encode(['success' => true]);

} elseif ($method === 'POST' && $action === 'update_rundown_order') {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!isset($data['csrf_token']) || $data['csrf_token'] !== $_SESSION['csrf_token']) {
        echo json_encode(['success' => false, 'error' => 'Invalid CSRF token.']);
        exit;
    }
    
    $user = $_SESSION['user'];
    if ($user['role_id'] != 3) {
        echo json_encode(['success' => false, 'error' => 'Permission Denied']);
        exit;
    }
    
    $ids = $data['ids'] ?? [];
    $rundownId = $data['rundown_id'] ?? null;
    
    if (!$rundownId) {
        echo json_encode(['success' => false, 'error' => 'Missing rundown ID']);
        exit;
    }
    
    if (!empty($ids)) {
        $db->beginTransaction();
        $stmt = $db->prepare("UPDATE rundown_stories SET order_index=? WHERE id=? AND rundown_id=?");
        foreach ($ids as $index => $rsId) {
            $stmt->execute([$index + 1, $rsId, $rundownId]);
        }
        $db->commit();
    }
    echo json_encode(['success' => true]);

} elseif ($method === 'POST' && $action === 'toggle_rundown_story_drop') {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!isset($data['csrf_token']) || $data['csrf_token'] !== $_SESSION['csrf_token']) {
        echo json_encode(['success' => false, 'error' => 'Invalid CSRF token.']);
        exit;
    }
    
    $user = $_SESSION['user'];
    if ($user['role_id'] != 3) {
        echo json_encode(['success' => false, 'error' => 'Permission Denied']);
        exit;
    }
    
    $rsId = $data['id'] ?? null;
    $isDropped = $data['is_dropped'] ?? 0;
    
    if ($rsId) {
        $stmt = $db->prepare("UPDATE rundown_stories SET is_dropped=? WHERE id=?");
        $stmt->execute([$isDropped, $rsId]);
    }
    echo json_encode(['success' => true]);

} elseif ($method === 'POST' && $action === 'toggle_lock_rundown') {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!isset($data['csrf_token']) || $data['csrf_token'] !== $_SESSION['csrf_token']) {
        echo json_encode(['success' => false, 'error' => 'Invalid CSRF token.']);
        exit;
    }
    
    $user = $_SESSION['user'];
    if ($user['role_id'] != 3) {
        echo json_encode(['success' => false, 'error' => 'Permission Denied']);
        exit;
    }
    
    $rundownId = $data['id'] ?? null;
    $isLocked = $data['is_locked'] ?? 1;
    
    if ($rundownId) {
        $stmt = $db->prepare("UPDATE rundowns SET is_locked=? WHERE id=?");
        $stmt->execute([$isLocked, $rundownId]);
    }
    echo json_encode(['success' => true]);

} elseif ($method === 'GET' && $action === 'get_programs') {
    $stmt = $db->query("SELECT * FROM programs ORDER BY name ASC");
    echo json_encode(['success' => true, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);

} elseif ($method === 'POST' && $action === 'save_program') {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!isset($data['csrf_token']) || $data['csrf_token'] !== $_SESSION['csrf_token']) {
        echo json_encode(['success' => false, 'error' => 'Invalid CSRF token.']);
        exit;
    }
    
    $user = $_SESSION['user'];
    if ($user['role_id'] != 3) {
        echo json_encode(['success' => false, 'error' => 'Permission Denied']);
        exit;
    }
    
    $id = $data['id'] ?? null;
    $name = trim($data['name'] ?? '');
    $duration = intval($data['duration'] ?? 0);
    $breakCount = intval($data['break_count'] ?? 0);
    
    if (empty($name)) {
        echo json_encode(['success' => false, 'error' => 'Name cannot be empty']);
        exit;
    }

    if ($id) {
        $stmt = $db->prepare("UPDATE programs SET name=?, duration=?, break_count=? WHERE id=?");
        $stmt->execute([$name, $duration, $breakCount, $id]);
    } else {
        $stmt = $db->prepare("INSERT INTO programs (name, duration, break_count) VALUES (?, ?, ?)");
        $stmt->execute([$name, $duration, $breakCount]);
    }
    echo json_encode(['success' => true]);

} elseif ($method === 'POST' && $action === 'delete_program') {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!isset($data['csrf_token']) || $data['csrf_token'] !== $_SESSION['csrf_token']) {
        echo json_encode(['success' => false, 'error' => 'Invalid CSRF token.']);
        exit;
    }
    
    $user = $_SESSION['user'];
    if ($user['role_id'] != 3) {
        echo json_encode(['success' => false, 'error' => 'Permission Denied']);
        exit;
    }
    
    $id = $data['id'] ?? null;
    if ($id) {
        $stmt = $db->prepare("DELETE FROM programs WHERE id=?");
        $stmt->execute([$id]);
    }
    echo json_encode(['success' => true]);

} else {
    echo json_encode(['success' => false, 'error' => 'Invalid Action']);
}


function thai_soundex($text) {
    if (empty($text)) return '';
    // Remove vowels, tone marks and special characters
    $text = preg_replace('/[ะ-ูเ-ไๆฯิ-ื์]/u', '', $text);
    
    // Convert to uppercase phonetic groups based loosely on LK82
    $map = [
        '/[กขคฆฅฃ]/u' => 'K',
        '/[จฉชซฌศษส]/u' => 'S',
        '/[ดฎตฏทธฑฒถฐ]/u' => 'T',
        '/[บปพภผฝฟ]/u' => 'P',
        '/[รลฬณน]/u' => 'N',
        '/[ง]/u' => 'G',
        '/[ม]/u' => 'M',
        '/[ว]/u' => 'W',
        '/[ยญ]/u' => 'Y',
        '/[อหฮ]/u' => 'H'
    ];
    
    $result = preg_replace(array_keys($map), array_values($map), $text);
    // Remove double phonetic letters (e.g. KK -> K)
    $result = preg_replace('/(.)\1+/', '$1', $result);
    if (empty($result)) return '';
    // Maximum 6 chars for soundex depth limit to prevent over-matching
    return mb_substr($result, 0, 6, 'UTF-8');
}
